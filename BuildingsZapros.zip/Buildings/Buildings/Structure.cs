﻿using System;
using System.Collections.Generic;

namespace Buildings;

public partial class Structure
{
    public int IdBuilding { get; set; }

    public string? TypeOfStructure { get; set; }

    public virtual ICollection<Sale> Sales { get; set; } = new List<Sale>();
}

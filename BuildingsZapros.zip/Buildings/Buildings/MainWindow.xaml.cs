﻿using System;
using System.Data;
using System.Reflection.PortableExecutable;
using System.Windows;
using System.Windows.Controls;
using Microsoft.Data.Sqlite;

namespace Buildings
{
    public partial class MainWindow : Window
    {
        private string connectionString = "Data Source=D:\\Новая папка (6)\\Buildings\\Building_.db";

        public MainWindow()
        {
            InitializeComponent();
            LoadData();
            LoadStats();
            LoadStructureTypes();
        }

        private DataTable ExecuteSqlQuery(string sql)
        {
            var dataTable = new DataTable();

            using (var connection = new SqliteConnection(connectionString))
            {
                connection.Open();
                using (var command = new SqliteCommand(sql, connection))
                {
                    using (var reader = command.ExecuteReader())
                    {
                        dataTable.Load(reader);
                    }
                }
            }

            return dataTable;
        }

        private void ExecuteNonQuery(string sql)
        {
            using (var connection = new SqliteConnection(connectionString))
            {
                connection.Open();
                using (var command = new SqliteCommand(sql, connection))
                {
                    command.ExecuteNonQuery();
                }
            }
        }

        public void LoadData()
        {
            try
            {
                string sql = @"
                    SELECT s.id, st.type_of_structure, s.num_of_rooms, s.footage, s.price 
                    FROM Sale s
                    JOIN Structure st ON s.type_of_structure = st.id_building";

                DtgSale.ItemsSource = ExecuteSqlQuery(sql).DefaultView;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при загрузке данных: {ex.Message}");
            }
        }

        private void LoadStructureTypes()
        {
            try
            {
                string sql = "SELECT id_building, type_of_structure FROM Structure";
                CmbFiltr.ItemsSource = ExecuteSqlQuery(sql).DefaultView;
                CmbFiltr.DisplayMemberPath = "type_of_structure";
                CmbFiltr.SelectedValuePath = "id_building";
                CmbFiltr.SelectedIndex = -1;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при загрузке типов строений: {ex.Message}");
            }
        }

        private void LoadStats()
        {
            string sql = @"
                SELECT 
                    MIN(price) as min_price,
                    MAX(price) as max_price,
                    AVG(footage) as avg_footage
                FROM Sale";

            var stats = ExecuteSqlQuery(sql).Rows[0];
            TxtStats.Text = $"Мин. цена: {Convert.ToDouble(stats["min_price"]):N0} ₽ | Макс. цена: {Convert.ToDouble(stats["max_price"]):N0} ₽ | Ср. метраж: {Convert.ToDouble(stats["avg_footage"]):N1} м²";
        }

        private void BtnSearch_Click(object sender, RoutedEventArgs e)
        {
            string searchText = TxtSearch.Text.Trim();

            if (string.IsNullOrWhiteSpace(searchText))
            {
                LoadData();
                return;
            }

            string sql = $@"
                SELECT s.id, st.type_of_structure, s.num_of_rooms, s.footage, s.price 
                FROM Sale s
                JOIN Structure st ON s.type_of_structure = st.id_building
                WHERE LOWER(st.type_of_structure) LIKE '%{searchText.ToLower()}%'
                   OR s.num_of_rooms LIKE '%{searchText}%'
                   OR s.footage LIKE '%{searchText}%'
                   OR s.price LIKE '%{searchText}%'";

            DtgSale.ItemsSource = ExecuteSqlQuery(sql).DefaultView;
            LoadStats();
        }

        private void BtnSortUp_Click(object sender, RoutedEventArgs e)
        {
            string sql = @"
                SELECT s.id, st.type_of_structure, s.num_of_rooms, s.footage, s.price 
                FROM Sale s
                JOIN Structure st ON s.type_of_structure = st.id_building
                ORDER BY s.price ASC";

            DtgSale.ItemsSource = ExecuteSqlQuery(sql).DefaultView;
        }

        private void BtnSortDown_Click(object sender, RoutedEventArgs e)
        {
            string sql = @"
                SELECT s.id, st.type_of_structure, s.num_of_rooms, s.footage, s.price 
                FROM Sale s
                JOIN Structure st ON s.type_of_structure = st.id_building
                ORDER BY s.price DESC";

            DtgSale.ItemsSource = ExecuteSqlQuery(sql).DefaultView;
        }

        private void CmbFiltr_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (CmbFiltr.SelectedValue != null)
            {
                string sql = $@"
                    SELECT s.id, st.type_of_structure, s.num_of_rooms, s.footage, s.price 
                    FROM Sale s
                    JOIN Structure st ON s.type_of_structure = st.id_building
                    WHERE s.type_of_structure = {CmbFiltr.SelectedValue}";

                DtgSale.ItemsSource = ExecuteSqlQuery(sql).DefaultView;
                LoadStats();
            }
            else
            {
                LoadData();
            }
        }

        private void BtnResetAll_Click(object sender, RoutedEventArgs e)
        {
            TxtSearch.Clear();
            CmbFiltr.SelectedIndex = -1;
            LoadData();
            LoadStats();
        }

        private void BtnAddStructureType_Click(object sender, RoutedEventArgs e)
        {
            var dialog = new InputDialog("Введите новый тип строения:");
            if (dialog.ShowDialog() == true)
            {
                string newType = dialog.Answer;
                if (!string.IsNullOrWhiteSpace(newType))
                {
                    string sql = $"INSERT INTO Structure (type_of_structure) VALUES ('{newType}')";
                    ExecuteNonQuery(sql);
                    LoadStructureTypes();
                    MessageBox.Show("Тип строения успешно добавлен!");
                }
            }
        }

        private void BtnAddBuilding_Click(object sender, RoutedEventArgs e)
        {
            var dialog = new AddBuildingDialog(connectionString);
            if (dialog.ShowDialog() == true)
            {
                string sql = $@"
                    INSERT INTO Sale (type_of_structure, num_of_rooms, footage, price)
                    VALUES ({dialog.TypeId}, {dialog.Rooms}, {dialog.Footage}, {dialog.Price})";

                ExecuteNonQuery(sql);
                LoadData();
                LoadStats();
                MessageBox.Show("Строение успешно добавлено!");
            }
        }

        private void BtnSave_Click(object sender, RoutedEventArgs e)
        {
            // В нашем случае данные сохраняются сразу при добавлении/изменении,
            // поэтому просто покажем сообщение
            MessageBox.Show("Все изменения уже сохранены в базе данных.");
        }

        private void BtnDelete_Click(object sender, RoutedEventArgs e)
        {
            if (DtgSale.SelectedItem is DataRowView row)
            {
                int id = Convert.ToInt32(row["id"]);
                if (MessageBox.Show("Вы уверены, что хотите удалить эту запись?", "Подтверждение",
                    MessageBoxButton.YesNo) == MessageBoxResult.Yes)
                {
                    string sql = $"DELETE FROM Sale WHERE id = {id}";
                    ExecuteNonQuery(sql);
                    LoadData();
                    LoadStats();
                    MessageBox.Show("Запись успешно удалена!");
                }
            }
            else
            {
                MessageBox.Show("Пожалуйста, выберите запись для удаления.");
            }
        }
    }
}
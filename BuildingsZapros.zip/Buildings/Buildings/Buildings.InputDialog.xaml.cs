﻿using System.Windows;

namespace Buildings
{
    public partial class InputDialog : Window
    {
        public string Answer { get; set; }

        public InputDialog(string question)
        {
            InitializeComponent();
            QuestionText.Text = question;
        }

        private void OkButton_Click(object sender, RoutedEventArgs e)
        {
            Answer = AnswerTextBox.Text;
            DialogResult = true;
        }

        private void CancelButton_Click(object sender, RoutedEventArgs e)
        {
            DialogResult = false;
        }
    }
}
﻿using System;
using System.Collections.Generic;

namespace Buildings;

public partial class Sale
{
    public int Id { get; set; }

    public int TypeOfStructure { get; set; }

    public int NumOfRooms { get; set; }

    public double Footage { get; set; }

    public double Price { get; set; }

    public virtual Structure TypeOfStructureNavigation { get; set; } = null!;
}

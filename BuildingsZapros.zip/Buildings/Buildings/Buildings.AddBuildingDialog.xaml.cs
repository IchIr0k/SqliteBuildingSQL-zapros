﻿using System.Data;
using System.Windows;
using Microsoft.Data.Sqlite;

namespace Buildings
{
    public partial class AddBuildingDialog : Window
    {
        public int TypeId { get; set; }
        public int Rooms { get; set; }
        public double Footage { get; set; }
        public double Price { get; set; }

        private string connectionString;

        public AddBuildingDialog(string connectionString)
        {
            InitializeComponent();
            this.connectionString = connectionString;
            LoadStructureTypes();
        }

        private void LoadStructureTypes()
        {
            string sql = "SELECT id_building, type_of_structure FROM Structure";
            var dataTable = new DataTable();

            using (var connection = new SqliteConnection(connectionString))
            {
                connection.Open();
                using (var command = new SqliteCommand(sql, connection))
                {
                    using (var reader = command.ExecuteReader())
                    {
                        dataTable.Load(reader);
                    }
                }
            }

            TypeComboBox.ItemsSource = dataTable.DefaultView;
            TypeComboBox.DisplayMemberPath = "type_of_structure";
            TypeComboBox.SelectedValuePath = "id_building";
        }

        private void OkButton_Click(object sender, RoutedEventArgs e)
        {
            if (TypeComboBox.SelectedValue == null ||
                !int.TryParse(RoomsTextBox.Text, out int rooms) ||
                !double.TryParse(FootageTextBox.Text, out double footage) ||
                !double.TryParse(PriceTextBox.Text, out double price))
            {
                MessageBox.Show("Пожалуйста, заполните все поля корректно!");
                return;
            }

            TypeId = (int)TypeComboBox.SelectedValue;
            Rooms = rooms;
            Footage = footage;
            Price = price;

            DialogResult = true;
        }

        private void CancelButton_Click(object sender, RoutedEventArgs e)
        {
            DialogResult = false;
        }
    }
}